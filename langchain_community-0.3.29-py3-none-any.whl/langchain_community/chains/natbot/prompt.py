from langchain.chains.natbot.prompt import PROMPT

__all__ = ["PROMPT"]
